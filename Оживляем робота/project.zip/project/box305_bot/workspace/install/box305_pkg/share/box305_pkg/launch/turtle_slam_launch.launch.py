import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

TURTLEBOT3_MODEL = os.environ.get('TURTLEBOT3_MODEL', 'burger')

def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    use_rviz = LaunchConfiguration('use_rviz', default='true')
    # Для динамического SLAM передаём пустую карту
    map_arg = LaunchConfiguration('map', default='')

    param_file_name = TURTLEBOT3_MODEL + '.yaml'
    param_dir = LaunchConfiguration(
        'params_file',
        default=os.path.join(
            get_package_share_directory('turtlebot3_navigation2'),
            'param',
            param_file_name))

    nav2_launch_file_dir = os.path.join(
        get_package_share_directory('nav2_bringup'), 'launch')

    rviz_config_dir = os.path.join(
        get_package_share_directory('nav2_bringup'),
        'rviz',
        'nav2_default_view.rviz')

    # Определяем путь к launch файлу slam_toolbox
    slam_toolbox_launch_file = os.path.join(
        get_package_share_directory('slam_toolbox'),
        'launch',
        'online_async_launch.py')

    return LaunchDescription([
        DeclareLaunchArgument(
            'map',
            default_value='',
            description='Пустой аргумент для карты, чтобы Nav2 не загружал статическую карту'),

        DeclareLaunchArgument(
            'params_file',
            default_value=param_dir,
            description='Полный путь до файла параметров для Nav2'),

        DeclareLaunchArgument(
            'use_sim_time',
            default_value='true',
            description='Использовать симуляционное время, если true'),

        # Запуск SLAM Toolbox для динамической генерации карты
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(slam_toolbox_launch_file),
            launch_arguments={'use_sim_time': use_sim_time}.items()
        ),

        # Запуск Nav2 bringup без статической карты
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(nav2_launch_file_dir, 'bringup_launch.py')),
            launch_arguments={
                'map': map_arg,
                'use_sim_time': use_sim_time,
                'params_file': param_dir}.items(),
        ),

        # Запуск RViz для визуализации
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config_dir],
            parameters=[{'use_sim_time': use_sim_time}],
            condition=IfCondition(use_rviz),
            output='screen'),
    ])
