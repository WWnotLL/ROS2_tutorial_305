import serial
import threading
import time

class SerialSender:
    def __init__(self, port, baudrate=9600, timeout=1):
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.serial_conn = serial.Serial(port, baudrate, timeout=timeout)
        
        # Параметры для отправки
        self.speed_right = 0
        self.speed_left = 0
        
        # Последние полученные 4 целых числа
        self.last_received_values = [0, 0, 0, 0]
        self._lock = threading.Lock()
        
        # Флаги остановки для потоков
        self._stop_event = threading.Event()
        
        # Потоки для отправки и приёма данных
        self._send_thread = threading.Thread(target=self._send_loop)
        self._receive_thread = threading.Thread(target=self._receive_loop)

    def start(self):
        self._stop_event.clear()
        if not self._send_thread.is_alive():
            self._send_thread = threading.Thread(target=self._send_loop)
            self._send_thread.start()
        if not self._receive_thread.is_alive():
            self._receive_thread = threading.Thread(target=self._receive_loop)
            self._receive_thread.start()

    def stop(self):
        self._stop_event.set()
        if self._send_thread.is_alive():
            self._send_thread.join()
        if self._receive_thread.is_alive():
            self._receive_thread.join()
        if self.serial_conn.is_open:
            self.serial_conn.close()

    def update_values(self, speed_right, speed_left):
        self.speed_right = self._clip_and_convert(speed_right)
        self.speed_left = self._clip_and_convert(speed_left)

    def _clip_and_convert(self, value):
        return int(max(min(value, 1000), -1000))

    def _send_loop(self):
        interval = 0.1  # 10 Гц => каждые 0.1 секунды
        while not self._stop_event.is_set():
            data_str = f"{self.speed_right} {self.speed_left}\n"
            self.serial_conn.write(data_str.encode('utf-8'))
            time.sleep(interval)

    def _receive_loop(self):
        while not self._stop_event.is_set():
            try:
                # Метод readline() ожидает появления '\n' в конце строки.
                line = self.serial_conn.readline()
                #print(line)
                if not line:
                    continue
                decoded_line = line.decode('utf-8').strip()
                parts = decoded_line.split()
                if len(parts) == 4:
                    values = list(map(int, parts))
                    with self._lock:
                        self.last_received_values = values
            except Exception:
                # В случае ошибки декодирования или преобразования можно просто пропустить данную строку
                continue

    def get_received_values(self):
        with self._lock:
            return self.last_received_values.copy()

# Пример использования модуля:
if __name__ == "__main__":
    sender = SerialSender(port='/dev/ttyUSB0', baudrate=115200)
    sender.start()
    try:
        # Отправка новых значений каждые 2 секунды
        for i in range(-1000, 1001, 500):
            sender.update_values(speed_right=i, speed_left=i)
            #print(f"Отправляем: {i} (правые), {-i} (левые)")
            time.sleep(2)
            # Чтение последних полученных данных
            received = sender.get_received_values()
            #print(f"Получено: {received}")
    except KeyboardInterrupt:
        pass
    finally:
        sender.stop()
        print("Отправка и приём завершены.")
