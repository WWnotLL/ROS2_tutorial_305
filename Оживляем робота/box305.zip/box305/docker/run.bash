#!/bin/bash

# Определяем директорию, где находится скрипт
SIM_ROOT="$( cd "$(dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Получаем IP-адрес хоста
HOST_IP=$(grep nameserver /etc/resolv.conf | awk '{print $2}')

# Разрешаем docker доступ к X-серверу
xhost +local:docker > /dev/null || true

# Имя образа, которое будет использоваться (после сборки Dockerfile)
IMG_NAME="box305:latest"

### Запуск контейнера ----------------------------------------------------------- #

docker run -d -ti --rm \
    -e "DISPLAY" \
    -e "QT_X11_NO_MITSHM=1" \
    -e "ROS_HOSTNAME=localhost" \
    -e HOST_IP=$HOST_IP \
    -e XAUTHORITY \
    -v /tmp/.X11-unix:/tmp/.X11-unix:rw \
    -v /etc/localtime:/etc/localtime:ro \
    -v "${SIM_ROOT}/../workspace:/root/ros2_ws" \
    -p 8080:8080 \
    --privileged \
    --name "ros2_box305_turtle" ${IMG_NAME} \
    > /dev/null