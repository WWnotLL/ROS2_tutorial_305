#!/bin/bash

docker stop "ros2_box305_turtle" > /dev/null
