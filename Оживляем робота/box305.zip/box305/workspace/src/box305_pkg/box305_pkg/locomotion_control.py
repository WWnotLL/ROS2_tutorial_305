#!/usr/bin/env python3
import math
import time

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TransformStamped
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster

from box305_pkg import motor_driver


class LocomotionControl(Node):
    def __init__(self):
        super().__init__('locomotion_control')

        # Параметры робота
        self.wheel_base = 0.5        # расстояние между колёсами (метров)
        self.max_cmd = 1000          # максимальное значение для команд (используется в SerialSender)
        self.cmd_scale = 500         # коэффициент масштабирования для преобразования м/с в команду
        self.encoder_ticks_per_rev = 500  # количество импульсов энкодера на оборот колеса
        self.wheel_circumference = 2 * math.pi * 0.1  # длина окружности колеса (при радиусе 0.1 м)

        # Инициализируем драйвер последовательного соединения
        self.serial_driver = motor_driver.SerialSender(port='/dev/ttyACM0', baudrate=115200)
        self.serial_driver.start()

        # Подписка на топик cmd_vel для получения команд движения
        self.create_subscription(Twist, 'cmd_vel', self.cmd_vel_callback, 10)

        # Публикация одометрии
        self.odom_pub = self.create_publisher(Odometry, 'odom', 10)

        # TF Broadcaster для трансляции tf между odom и base_link
        self.tf_broadcaster = TransformBroadcaster(self)

        # Таймер обновления одометрии (например, 20 Гц)
        self.odom_timer = self.create_timer(0.05, self.update_odom)

        # Хранение предыдущих значений энкодеров и времени для интеграции
        self.prev_left_encoder = None
        self.prev_right_encoder = None
        self.prev_time = self.get_clock().now()

        # Положение робота в одометрической системе координат
        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0

    def cmd_vel_callback(self, msg: Twist):
        """
        Преобразование команд cmd_vel в управляющие сигналы для правого и левого колёс.
        Используем дифференциальную модель робота:
            v_right = v + (L/2)*omega
            v_left  = v - (L/2)*omega
        Преобразуем м/с в управляющие команды (масштабирование).
        """
        linear = msg.linear.x      # м/с
        angular = msg.angular.z    # рад/с

        # Дифференциальное преобразование:
        v_right = linear + (self.wheel_base / 2.0) * angular
        v_left  = linear - (self.wheel_base / 2.0) * angular

        # Преобразуем скорости в команды (например, линейно масштабируем)
        cmd_right = int(max(min(v_right * self.cmd_scale, self.max_cmd), -self.max_cmd))
        cmd_left = int(max(min(v_left * self.cmd_scale, self.max_cmd), -self.max_cmd))

        self.get_logger().info(
            f"Получена cmd_vel: linear={linear:.2f}, angular={angular:.2f} => команды: правые={cmd_right}, левые={cmd_left}"
        )

        # Обновляем управляющие команды для драйвера
        self.serial_driver.update_values(speed_right=cmd_right, speed_left=cmd_left)

    def update_odom(self):
        """
        Чтение показаний энкодеров, вычисление одометрии и публикация сообщений /odom и tf.
        """
        current_time = self.get_clock().now()
        dt = (current_time - self.prev_time).nanoseconds * 1e-9
        if dt == 0:
            return

        # Чтение текущих показаний энкодеров
        enc_values = self.serial_driver.get_received_values()
        if len(enc_values) < 2:
            return
        left_encoder = enc_values[0]
        right_encoder = enc_values[1]

        # Инициализация предыдущих значений при первом запуске
        if self.prev_left_encoder is None or self.prev_right_encoder is None:
            self.prev_left_encoder = left_encoder
            self.prev_right_encoder = right_encoder
            self.prev_time = current_time
            return

        # Разница импульсов
        delta_left = left_encoder - self.prev_left_encoder
        delta_right = right_encoder - self.prev_right_encoder

        # Сохраняем текущие показания для следующего расчёта
        self.prev_left_encoder = left_encoder
        self.prev_right_encoder = right_encoder
        self.prev_time = current_time

        # Преобразуем разницу импульсов в пройденное расстояние
        # Допустим, один оборот колеса = encoder_ticks_per_rev импульсов
        # И расстояние = (кол-во оборотов) * circumference
        dist_left = (delta_left / self.encoder_ticks_per_rev) * self.wheel_circumference
        dist_right = (delta_right / self.encoder_ticks_per_rev) * self.wheel_circumference

        # Среднее пройденное расстояние и изменение угла
        d = (dist_left + dist_right) / 2.0
        delta_yaw = (dist_right - dist_left) / self.wheel_base

        # Обновление положения робота
        self.x += d * math.cos(self.yaw + delta_yaw / 2.0)
        self.y += d * math.sin(self.yaw + delta_yaw / 2.0)
        self.yaw += delta_yaw

        # Публикуем одометрическое сообщение
        odom_msg = Odometry()
        odom_msg.header.stamp = current_time.to_msg()
        odom_msg.header.frame_id = 'odom'
        odom_msg.child_frame_id = 'base_link'

        # Записываем позицию
        odom_msg.pose.pose.position.x = self.x
        odom_msg.pose.pose.position.y = self.y
        odom_msg.pose.pose.position.z = 0.0
        # Преобразуем угол yaw в кватернион
        qz = math.sin(self.yaw / 2.0)
        qw = math.cos(self.yaw / 2.0)
        odom_msg.pose.pose.orientation.z = qz
        odom_msg.pose.pose.orientation.w = qw

        # Скорости (рассчитаны как d/dt)
        odom_msg.twist.twist.linear.x = d / dt
        odom_msg.twist.twist.angular.z = delta_yaw / dt

        self.odom_pub.publish(odom_msg)

        # Отправка tf-перехода
        t = TransformStamped()
        t.header.stamp = current_time.to_msg()
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_link'
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0
        t.transform.rotation.z = qz
        t.transform.rotation.w = qw
        self.tf_broadcaster.sendTransform(t)

    def destroy_node(self):
        # При завершении работы узла останавливаем драйвер
        self.serial_driver.stop()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = LocomotionControl()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
