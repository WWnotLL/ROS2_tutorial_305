#!/usr/bin/env python3
import os
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # Статический трансформ от odom к base_link (без смещения и поворотов)
    static_transform_odom_to_base = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_transform_odom_to_base',
        arguments=['0', '0', '0', '0', '0', '0', 'odom', 'base_link']
    )

    # Статический трансформ от base_link к laser_frame
    # Измените аргументы в соответствии с реальным положением лазера на роботе
    static_transform_base_to_laser = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_transform_base_to_laser',
        arguments=['0.2', '0', '0.1', '0', '0', '0', 'base_link', 'laser_frame']
    )

    # Узел slam_toolbox, подписывающийся на топик /scan
    slam_toolbox_node = Node(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',  # Можно использовать online_sync, если требуется синхронный режим
        name='slam_toolbox',
        output='screen',
        parameters=[{
            'use_sim_time': False,  # Если используете симуляцию, установите True
            'scan_topic': '/scan',
            'odom_frame': 'odom',
            'base_frame': 'base_link',
            'map_frame': 'map',
            'max_laser_range': 10.0,
            # При необходимости увеличьте терпение при поиске трансформаций
            'transform_tolerance': 0.2  
        }]
    )

    return LaunchDescription([
        static_transform_odom_to_base,
        static_transform_base_to_laser,
        slam_toolbox_node
    ])
